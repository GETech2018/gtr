
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$animation$_$first = ''
        let normal$_$animation$_$second = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$calorie$_$current$_$text_img = ''
        let normal$_$calorie$_$image_progress$_$img_level = ''
        let normal$_$pai$_$weekly$_$text_img = ''
        let normal$_$pai$_$image_progress$_$img_level = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$date$_$img_date = ''
        let normal$_$week$_$week = ''
        let normal$_$aqi$_$image_progress$_$img_level = ''
        let normal$_$heart_rate$_$text$_$text_img = ''
        let normal$_$heart_rate$_$text$_$separator_img = ''
        let normal$_$heart_rate$_$image_progress$_$img_level = ''
        let normal$_$uvi$_$text$_$text_img = ''
        let normal$_$uvi$_$text$_$separator_img = ''
        let normal$_$humidity$_$text$_$text_img = ''
        let normal$_$humidity$_$text$_$separator_img = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$temperature$_$current$_$separator_img = ''
        let normal$_$temperature$_$high$_$text_img = ''
        let normal$_$temperature$_$high$_$separator_img = ''
        let normal$_$temperature$_$low$_$text_img = ''
        let normal$_$temperature$_$low$_$separator_img = ''
        let normal$_$distance$_$text$_$text_img = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$dnd$_$img = ''
        let normal$_$system$_$clock$_$img = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let idle$_$idle_background$_$bg = ''
        let idle$_$digital_clock$_$img_time = ''
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$animation$_$first = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 138,
              y: 140,
              anim_path: '',
              anim_prefix: 'first_anim',
              anim_ext: 'png',
              anim_fps: 1000,
              anim_size: 20,
              anim_repeat: true,
              repeat_count: 255,
              anim_status: hmUI.anim_status.START,
            });

                    
            normal$_$animation$_$second = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 96,
              y: 98,
              anim_path: '',
              anim_prefix: 'second_anim',
              anim_ext: 'png',
              anim_fps: 1,
              anim_size: 12,
              anim_repeat: true,
              repeat_count: 255,
              anim_status: hmUI.anim_status.START,
            });

                    
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 218,
              type: hmUI.data_type.BATTERY,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '12.png',//单位
              unit_tc: '12.png',//单位
              unit_en: '12.png',//单位
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 140,
              image_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 388,
              y: 257,
              type: hmUI.data_type.STEP,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$step$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 388,
              y: 280,
              type: hmUI.data_type.CAL,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '34.png',//单位
              unit_tc: '34.png',//单位
              unit_en: '34.png',//单位
              invalid_image: '33.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$calorie$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 29,
              y: 25,
              image_array: ["35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$pai$_$weekly$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 394,
              y: 302,
              type: hmUI.data_type.PAI_WEEKLY,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$pai$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 57,
              image_array: ["45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 165,
              hour_startY: 318,
              hour_array: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              hour_space: 0,
              hour_unit_sc: '65.png',
              hour_unit_tc: '65.png',
              hour_unit_en: '65.png',
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_array: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              minute_follow: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 297,
              month_startY: 147,
              month_sc_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              month_tc_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              month_en_array: ["66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 206,
              day_startY: 108,
              day_sc_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              day_tc_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              day_en_array: ["78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 108,
              y: 145,
              week_en: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              week_tc: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              week_sc: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
                    
            normal$_$aqi$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 235,
              image_array: ["95.png","96.png","97.png","98.png","99.png","100.png"],
              image_length: 6,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 387,
              type: hmUI.data_type.HEART,
              font_array: ["101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '112.png',//单位
              unit_tc: '112.png',//单位
              unit_en: '112.png',//单位
              invalid_image: '111.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$heart_rate$_$text$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 1,
              h: 9,
              src: '113.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$heart_rate$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 78,
              y: 312,
              image_array: ["114.png","115.png","116.png","117.png","118.png","119.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$uvi$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 261,
              type: hmUI.data_type.UVI,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '121.png',//单位
              unit_tc: '121.png',//单位
              unit_en: '121.png',//单位
              invalid_image: '120.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$uvi$_$text$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 1,
              h: 9,
              src: '122.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$humidity$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 49,
              y: 281,
              type: hmUI.data_type.HUMIDITY,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '124.png',//单位
              unit_tc: '124.png',//单位
              unit_en: '124.png',//单位
              invalid_image: '123.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$humidity$_$text$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 1,
              h: 9,
              src: '125.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 316,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","134.png","135.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '138.png',//单位
              unit_en: '139.png',//单位
              negative_image: '137.png', //负号图片
              invalid_image: '136.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$current$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 1,
              h: 9,
              src: '140.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$high$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 20,
              y: 307,
              type: hmUI.data_type.WEATHER_HIGH,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '143.png',//单位
              unit_en: '144.png',//单位
              negative_image: '142.png', //负号图片
              invalid_image: '141.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$high$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 5,
              h: 4,
              src: '145.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$temperature$_$low$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 348,
              type: hmUI.data_type.WEATHER_LOW,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '148.png',//单位
              unit_en: '149.png',//单位
              negative_image: '147.png', //负号图片
              invalid_image: '146.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$temperature$_$low$_$separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 5,
              h: 4,
              src: '150.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 367,
              y: 234,
              type: hmUI.data_type.DISTANCE,
              font_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              align_h: hmUI.align.RIGHT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              dot_image: '151.png', //小数点图片
              padding: false,
              isCharacter: false
            });
  
                    
            normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 231,
              src: '152.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 116,
              y: 287,
              src: '153.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 313,
              y: 279,
              src: '154.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 323,
              image_array: ["155.png","156.png","157.png","158.png","159.png","160.png","161.png","162.png","163.png","164.png","165.png","166.png","167.png","168.png","169.png","170.png","171.png","172.png","173.png","174.png","175.png","176.png","177.png","178.png","179.png","180.png","181.png","182.png","183.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                    
            idle$_$idle_background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '184.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

                    
            idle$_$digital_clock$_$img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_zero: 1,
              hour_startX: 165,
              hour_startY: 318,
              hour_array: ["185.png","186.png","187.png","188.png","189.png","190.png","191.png","192.png","193.png","194.png"],
              hour_space: 0,
              hour_unit_sc: '195.png',
              hour_unit_tc: '195.png',
              hour_unit_en: '195.png',
              hour_align: hmUI.align.LEFT,
              minute_zero: 1,
              minute_array: ["185.png","186.png","187.png","188.png","189.png","190.png","191.png","192.png","193.png","194.png"],
              minute_follow: 1,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  